---
name: pa-wow-dashboard
description: Build the Private Assets Week-over-Week (WoW) pipeline dashboards from weekly SF extract files. Produces two self-contained HTML files — PA_WoW_Dashboard.html (5 pages: Exec Summary, Summary, Global, WoW Change, Rec Sales WoW Analysis) and demo_Wow.html (the Rec Sales bridge only) — plus a validation report. Rec Sales includes a Sub Product breakdown of the bridge; Global includes region-stacked Sales/Cancels trend charts below the table. Trigger on: "build the PA WoW dashboard", "Private Assets week over week", "rebuild PA_WoW_Dashboard", "recreate the WoW dashboard", "refresh the pipeline waterfall", "run the WoW build", or when RA_/PCS_ weekly extract CSVs are dropped in a WoW Analysis / extracts folder.
---

# Private Assets — Week-over-Week (WoW) Dashboard builder

This skill regenerates the PA WoW dashboards **deterministically** from weekly Salesforce extract files. Same inputs → identical output. Everything runs locally in Python (pandas); the dashboards are single self-contained HTML files (data embedded, no external JS), so they can be emailed/shared and opened offline.

The build is **self-configuring**: it discovers its own folder, the available weekly snapshots, the current week, the baselines, and the quarter. In the normal case you only drop new extracts in `extracts/` and run it — no code edits.

## What it produces (saved into the user's WoW Analysis folder)
- **PA_WoW_Dashboard.html** — full dashboard, 5 pages:
  1. **Exec Summary** — at-a-glance executive view (no filters): the 5 metrics repeated across every cut (Total PA, Real Assets, PCS, Americas, APAC, EMEA) as small-multiple 4-bar charts (Current / Prior / prior-year quarter / Target) with Δ vs Prior, Δ vs Target and % to target. Default landing page; the Segment/Region filter bar is hidden here (Compare-to baseline still applies).
  2. **Summary** — Recurring / Cancels / Non-Recurring / Rec Net New / Total Net New bars (Current / Prior / prior-year actual / current-quarter Target) with Δ vs Prior and Δ vs Target. Filter-driven (Segment/Region).
  3. **Global** — multi-week time series (one column per weekly snapshot in /extracts). Recurring sales only (New Actual & New open pipeline); target = recurring New Sales target. Rows are grouped into blocks separated by a thick rule (see *Global page row blocks*). Below the table, two region-stacked bar charts — **Sales Forecast trend** and **Cancels Forecast trend** — one bar per weekly snapshot (see *Global page trend charts*).
  4. **WoW Change** — account-level variance tables.
  5. **Rec. Sales WoW Analysis** — the 7-logic open-pipeline bridge (L1 Converted, L2 Disqualified / Dropped, L3 Lost, L4 Movement, L5 New Pipeline, L6 Pushed / Pulled In, + L7 New Wins) with waterfall, #Deals summary, and line-item drill-downs. Includes a **Forecast Category filter** (All / Commit / Best Case / Omitted): when a category is chosen the whole bridge (opening, closing, all logics, waterfall, tables) re-scopes to it and two extra flows appear — **Category In** / **Category Out** (pipeline that switched into/out of the category week-over-week) — so Opening → Closing still reconciles. L4 Movement also lists forecast-category-only moves (tagged, $0 impact). Directly below the waterfall, a **Sub Product breakdown** table repeats the same bridge (Opening → L1..L6 → Closing) split by Sub Product New within each segment (see *Sub Product breakdown*).
- **demo_Wow.html** — standalone Rec. Sales bridge page (for previews) — same page 5 content (waterfall, Sub Product breakdown, logic tables, drill-downs) as the main dashboard, minus the other 4 pages.
- **_validation_report.txt** — automated checks (see below). Read it every run.

## Files in this skill package
- `build_wow.py` — the builder. Paths are derived from `os.path.abspath(__file__)`, so it runs from wherever it sits; no path editing, ever.
- `_dash_template.html`, `_demo_template.html` — HTML shells; the build injects the data into them. Quarter labels inside them are retargeted automatically (see *Quarter handling*), so the templates are never edited when the quarter rolls.
- `refs_edwh.json` — EDWH #SF reference values (targets + prior-year actuals by segment × region). Used for the Summary/Exec bars and Global targets.
- `extracts/` — a reference dataset (RA_/PCS_ CSVs) so a teammate can reproduce the exact same dashboards apple-to-apple. Replace/extend with the live weekly files.

## How to run (do these steps)
1. **Confirm the output folder.** The dashboards must be saved to the user's connected **WoW Analysis** folder. If none is connected, ask the user to connect one (request_cowork_directory).
2. **Copy this package's files into that folder** (keep the structure): `build_wow.py`, `_dash_template.html`, `_demo_template.html`, `refs_edwh.json`, and the `extracts/` subfolder.
3. **Install pandas** in the sandbox: `pip install pandas openpyxl --break-system-packages`.
4. **Check `refs_edwh.json` covers the quarter being built.** If the build prints a `WARNING: refs_edwh.json has no block for Qn-yy`, refresh it from EDWH first (see *Refreshing refs_edwh.json*) — otherwise every target and prior-year bar renders as 0.
5. **Run the build** from that folder: `python3 "<WoW Analysis path>/build_wow.py"`.
6. **Read `_validation_report.txt`.** It must say `OVERALL: ALL CHECKS PASSED`. If it says FAILED, do NOT share the dashboard — the report lists the exact segment/region and dollar gap to investigate.
7. **Present** `PA_WoW_Dashboard.html` and `demo_Wow.html` to the user (present_files).

## Input data contract (extracts/)
- One file per segment per weekly snapshot, named exactly: `RA_DD-MM-YYYY.csv` and `PCS_DD-MM-YYYY.csv` (e.g. `RA_17-07-2026.csv`). RA = Real Assets, PCS = Private Capital Solutions. A date is only usable when **both** files exist.
- Required columns: `Account Number`, `Opportunity Number`, `Product Display Name Primary`, `Child Account`, `Sales Owner Name`, `Finance Region_Clean`, `Fiscal Quarter-Year`, `Forecast Category Name`, `Stage Name`, `New Actual`, `New Open Opportunities`, `Cancel Actual`, `Cancels Open Opportunities`, `One Time Actual`, `One Time Open Opportunities`.
- Weekly extracts come from the **sf-mcp-extract** skill; column layout is identical, so its output can be renamed straight into `extracts/`.

## Date handling (automatic)
`CW_DATE=None` and `BASELINE_DATES={...None}` at the top of `build_wow.py` mean auto-detect — the normal mode:
- **Current week** = latest date with both RA and PCS files.
- **Prior week** = the snapshot immediately before CW (so an off-cadence file, e.g. a Thursday pull, still works).
- **Quarter start** = earliest snapshot inside CW's quarter.
- **Prior month** = the in-quarter snapshot closest to (CW − 1 month); it is only offered once CW is past the first month of the quarter, and is **auto-skipped when it resolves to the same file as Prior week or Quarter start** (the build prints "Prior month baseline skipped…"). Early in a quarter, expect only two baselines.
- Pin any of them with `"DD-MM-YYYY"` strings only when a specific comparison is requested. Missing files raise a clear error naming the dates.
- The **Global** page always shows one column per available weekly file.

## Quarter handling (automatic)
- `Q_OVERRIDE=None` → the quarter is derived from the CW snapshot date (`Q{(month-1)//3+1}-{yy}`; MSCI fiscal = calendar). The build prints the derived quarter and **hard-fails** if it isn't present in the CW extract, so a bad roll can't produce a silently empty dashboard.
- Set `Q_OVERRIDE="Q4-26"` to pin a quarter (e.g. to build next quarter's view early, or to rebuild an old one).
- `relabel_quarter()` retargets the templates' baked-in current-quarter and prior-year labels (all three separator variants: `Q3-26`, `Q3‑26`, `Q3'26`) **before** the data is injected — so no HTML editing is needed at quarter roll, and genuine quarter values inside the deal-level data are never rewritten.

## Refreshing refs_edwh.json (targets & prior-year actuals)
`refs_edwh.json` accepts two shapes; the loader detects which:
- **Quarter-keyed (preferred, multi-quarter):** `{"Q3-26": {"Real Assets|EMEA": {...}}, "Q4-26": {...}}` — lets several quarters live side by side, so rolling forward is additive rather than destructive.
- **Flat (legacy):** `{"Real Assets|EMEA": {...}}` — assumed to belong to the quarter being built.

Keys are `"<Segment>|<Region>"` for the 6 combinations (Real Assets / Private Capital Solutions × Americas / APAC / EMEA). Per-block fields: `q4New`, `q4Can`, `q4OT` (current-quarter target components), `tNew`, `tCan`, `tOT`, `tNN`, `tTNN`, `gT` (full-year / total figures).

**To refresh for a new quarter (do this at quarter roll):**
1. Use the EDWH connection that the **sf-mcp-extract** skill uses (`mcp__CSP_EDWH_MCP_Dev__execute_dax_query`, workspace `6a5fb876-2c85-482e-81e7-807a572da4c9`, dataset `83e66709-5d49-4bb2-959a-960e4bb2127c`). Note: the Prod EDWH tool returns 403 on this dataset — use the Dev tool.
2. Query the #SF Sales Forecast model for the target record type for the new quarter and the actuals for the same quarter one year earlier, grouped by `Products[Product Segment]` (Private Assets → RA / PCS) × `Sales Forecast[Finance Region_Clean]`. If a measure or record-type name is uncertain, run `search_column_mappings` first rather than guessing — a wrong filter here silently skews every target bar.
3. Write the results as a **new quarter block** in `refs_edwh.json`, keeping existing quarters intact.
4. Rerun the build and confirm it prints `REFS sourced from EDWH #SF (refs_edwh.json) for <Q> - 6 segment/region blocks`. Fewer than 6 blocks means a segment/region is missing.

## What the numbers mean (so it tells the correct story)
The Rec Sales page is an **open-pipeline bridge for the current quarter**: Opening pipeline → **L1 Converted to Actual** → **L2 Disqualified / Dropped** (shifted to a later quarter) → **L3 Lost** (gone from system) → **L4 Movement within the quarter** (same-quarter $ change) → **L5 New Pipeline build** → **L6 Pushed / Pulled In** (moved into the quarter from another quarter) → Closing pipeline. **L7 New Wins** (booked with no prior pipeline) is tracked separately, outside the bridge. Each logic bar = its detail-table total. Filters: Segment, Region, Compare-to baseline, and an "Exclude CAM placeholders" toggle.

### Global page row blocks
The Global table is deliberately split into a **forecast** block and a **gross pipeline** block, divided by a thick rule. Row order and definitions (all Q3 recurring, one column per weekly snapshot):

| Block | Rows | Definition |
|---|---|---|
| Forecast | QTD Actual, Commit, CAM Placeholder pipeline, **Total Forecast** | Total Forecast = QTD Actual + Commit + CAM Placeholder |
| Gross pipeline | Best Case, Omit, **Total Gross Pipeline** | Total Gross Pipeline = Commit + Best Case + Omit |
| Target | Quarter Target | recurring New Sales target from `refs_edwh.json` |
| Coverage | Pipeline to Target (Act+Commit+BC), Pipeline to Target (incl Omit), Best Case ÷ CAM Placeholder | unchanged coverage ratios |
| Advanced stage | Advanced Stage header + its two coverage ratios | Advanced = Contract, Renewal, Pending Renewal, PPR |

Two things to hold onto when editing these rows:
- **Commit / Best Case / Omit exclude CAM placeholders**; CAM is its own row. So Total Forecast adds cleanly with no double count. In practice all CAM pipeline sits in the Commit category.
- **Total Gross Pipeline is open pipeline only** — it excludes QTD Actual *and* CAM, so it deliberately does not tie to Total Forecast. It ties to the Rec Sales bridge closing balance as `Total Gross Pipeline + CAM = Closing pipeline`, which is a useful cross-page check.

Row specs live in one array in `_dash_template.html` (`renderGlobal`), shaped `[label, valueFn, isTotal, isRatio, isSectionHeader, startsNewBlock]`. Set the 6th flag to draw the thick rule above a row (`.blk` CSS class) — don't hand-insert spacer rows.

### Global page trend charts
Two hand-rolled SVG stacked-bar charts sit below the Global table, one bar per weekly snapshot, stacked by region (Americas navy, EMEA amber, APAC teal — `TREND_REGION_COLOR` in `_dash_template.html`):
- **Sales Forecast trend** — each region's segment = that region's QTD Actual + Commit pipeline + CAM Placeholder pipeline (i.e. the same three components as the table's Total Forecast row, just split by region instead of collapsed).
- **Cancels Forecast trend** — each region's segment = Cancel Actual + Cancels Open Opportunities, no forecast-category filter (matches how cancels are treated everywhere else on this dashboard). New data field — `global_for_date()` didn't compute cancels before this; it now returns 11 columns per row (`seg,region,QTD,Commit,BestCase,Omit,AdvStage,AdvStageOmit,CAMsales,Cancels,CAMcancels`), so `WOW_DATA.global` rows are 12-wide (week label prepended).

Both charts respect the page's Segment and Region filters exactly like the table above them (`isSeg`/`isReg`).

**CAM breakout on the latest bar only.** Every historical bar folds CAM into whichever region it sits in (3 segments per bar). The latest/current-week bar instead shows Americas/EMEA/APAC *without* their CAM, plus one extra combined CAM segment (grey, `TREND_CAM_COLOR`) — applies to both charts. The bar's total is identical either way; only the visual breakdown of the latest bar differs. This mirrors the CAM Placeholder pipeline row already being a distinct line in the table, and it applies to Cancels too even though there's no separate "CAM cancels" row in the table — check `camcancel` in `global_for_date()` before assuming it's always zero.

### Sub Product breakdown
A second bridge table on the Rec Sales page (main dashboard and demo alike), directly under the waterfall chart, grouped by Segment then Sub Product New, all 8 bridge columns (Opening → L1..L6 → Closing) plus Category In/Out when a Forecast Category filter is active. Sub Product New is a strict 1:1 function of Product Display Name Primary (part of the deal key already), so it threads through safely with no labelling ambiguity, unlike the quarter label.

Data lives in `SPWF`, built inside `classify()` in the exact same loop as the main `WF` (every increment mirrored line-for-line) so the two can never drift apart. Row layout, 14 columns per (forecast-category-scoped) entry: `seg,region,subprod,opening,conv,drop,lost,mov,new,push,catin,catout,closing,cam`. The top-level `D.SPWF` (12-col, catin/catout stripped) is the "All" convenience version; `D.fc[FCSEL].SPWF` (14-col) is what the front end actually reads via `L().SPWF`, since the table must respect the Forecast Category filter. Zero-value sub products are shown, not hidden — that's deliberate.

### Deal quarter labels ("follow the money")
A deal key (account + opportunity + product) often carries several `Fiscal Quarter-Year` rows, and the ones outside the current quarter are frequently **$0 placeholders**. Labelling the deal by its most frequent row therefore mislabels it — one $0 Q2-26 row plus one $775 Q3-26 row is a 1-1 tie that resolves alphabetically to Q2-26. The build instead weights each quarter by the dollars on it (`|New Open| + |New Actual|`) and takes the winner; ties prefer the current quarter, then the latest quarter; a deal that is $0 everywhere falls back to the row-count mode. The build prints how many deal-weeks this corrected.

This is a labelling rule, but it also makes the **L2-vs-L4 split** right: a deal whose dollars now sit in a later quarter reads as Dropped/shifted rather than same-quarter Movement. Bridge totals are unaffected either way.

## Built-in validation (runs automatically each build)
- (A) Waterfall bridge reconciles per segment/region (Opening + L1..L6 = Closing).
- (B) Opening & Closing match an **independent raw recompute straight from the CSVs** (total + per segment) — catches aggregation bugs.
- (C) Every detail table total = its waterfall bar.
- (D) Sign sanity (out-flows ≤ 0, in-flows ≥ 0).
- (E) Sub Product breakdown (SPWF) bridge reconciles per segment/region/CAM/sub-product row.
- (F) Sub Product breakdown, summed back across sub-product and region, ties to the (already-validated) segment-level WF total — Opening and Closing both checked.
- (Global) The two trend charts' Sales and Cancels totals tie to an **independent raw recompute straight from the CSVs**, for every weekly column (not just the latest) — reported as its own section in the report, separate from the per-baseline checks above.

Residuals of a few dollars are expected (per-row rounding) and are inside tolerance; anything larger is reported as a FAIL with the segment/region (or week) named.

## Notes
- Do not add validation logic to the HTML — it belongs in `build_wow.py` / the report file.
- Excel export sheet names must not contain `/` (invalid Excel worksheet names) — keep the sanitized names used in the template.
- Keep `build_wow.py` path-free: use `BASE_DIR` (derived from `__file__`), never a `/sessions/...` literal — those change every session.
