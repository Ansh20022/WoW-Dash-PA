PA WoW Dashboard package.
Run: pip install pandas --break-system-packages ; python3 build_wow.py ; open PA_WoW_Dashboard.html
Everything is derived from build_wow.py's own folder. Current week, baselines and quarter auto-detect
from the files in extracts/ -- drop the new weekly RA_/PCS_ CSVs in and rerun. Read _validation_report.txt
before sharing. At quarter roll, add the new quarter block to refs_edwh.json (see SKILL.md).
